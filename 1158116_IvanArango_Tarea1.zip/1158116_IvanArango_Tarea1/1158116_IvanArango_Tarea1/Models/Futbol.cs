﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace _1158116_IvanArango_Tarea1.Models
{
    public class Futbol
    {
        [Key]

        public string Nombre { get; set; }
        public string Equipo { get; set; }
        public int Edad { get; set; }
    }
}