﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace _1158116_IvanArango_Tarea1.Models
{
    public class Estudiantes
    {
        [Key]

        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Edad { get; set; }
        public string Carnet { get; set; }
    }
}