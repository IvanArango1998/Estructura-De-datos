﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _1158116_IvanArango_Tarea1.Models;

namespace _1158116_IvanArango_Tarea1.Controllers
{
    public class FutbolController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: /Futbol/
        public ActionResult Index()
        {
            return View(db.Futbols.ToList());
        }

        // GET: /Futbol/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Futbol futbol = db.Futbols.Find(id);
            if (futbol == null)
            {
                return HttpNotFound();
            }
            return View(futbol);
        }

        // GET: /Futbol/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Futbol/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Nombre,Equipo,Edad")] Futbol futbol)
        {
            if (ModelState.IsValid)
            {
                db.Futbols.Add(futbol);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(futbol);
        }

        // GET: /Futbol/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Futbol futbol = db.Futbols.Find(id);
            if (futbol == null)
            {
                return HttpNotFound();
            }
            return View(futbol);
        }

        // POST: /Futbol/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Nombre,Equipo,Edad")] Futbol futbol)
        {
            if (ModelState.IsValid)
            {
                db.Entry(futbol).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(futbol);
        }

        // GET: /Futbol/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Futbol futbol = db.Futbols.Find(id);
            if (futbol == null)
            {
                return HttpNotFound();
            }
            return View(futbol);
        }

        // POST: /Futbol/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            Futbol futbol = db.Futbols.Find(id);
            db.Futbols.Remove(futbol);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
