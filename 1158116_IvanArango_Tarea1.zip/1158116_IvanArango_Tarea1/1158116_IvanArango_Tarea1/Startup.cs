﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(_1158116_IvanArango_Tarea1.Startup))]
namespace _1158116_IvanArango_Tarea1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
