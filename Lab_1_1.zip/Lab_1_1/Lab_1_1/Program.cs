﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1_1
{
    public delegate bool DelegateComparacion(libro libro);

    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<libro> lista = new LinkedList<libro>();
            lista.AddLast(new libro() { id = 1, nombre = "El quijote", edicion = "Primero" , año = 1994});
            lista.AddLast(new libro() { id = 2, nombre = "baldor", edicion = "tercero" , año = 2018});
            lista.AddLast(new libro() { id = 3, nombre = "sr presidente", edicion = "segundo" , año = 2017});

            //Instancia del delegadi
            DelegateComparacion delegado = new DelegateComparacion(EsPrimeraEdicion);
            Console.WriteLine(delegado(lista.First()));

            //Parametro evaluacion 
            DelegateComparacion delagado2 = x => x.edicion == "Primero";
            /*
            DelegateComparacion delegado3 = x =>
            {

                if (x.año % 100 == 0)
                {
                    if (x.año % 4 == 0)
                    {
                        if (x.año % 3 == 1)
                        {

                            return true;
                        }
                    }
                }
                else
                    return false;
            };
            */
            //Buscar el libro con el nombre baldor
            var result = lista.Where(libro => libro.nombre == "baldor");
            var datos = lista.Where(variable => variable.id == 1).ToList();
            var resultadoSalario = lista.Where(x => x.precio > 3000).ToList();
            //var resultadoClub = lista.Where(x => x.Club >= "Dallar").ToList();
            // var  resultadoNombr = lista.Where(x => x.nombre == texto).ToList();
            var paraEliminar = lista.Where(variable => variable.id == 1).First();
            lista.Remove(paraEliminar);
            Console.WriteLine(result.First().nombre);
            Console.ReadKey();
                

        }
         static bool EsPrimeraEdicion(libro libro)
        {
            if (libro.edicion == "Primero")
            {
                return true;

            }
            else
                return false;
        }

        static libro EsBaldor(libro libro)
        {
            if(libro.nombre == "baldor")
                return libro;
            else 
                return null;
        }
    }
}
   
        public class libro
        {
            public int id { get; set; }
            public string nombre { get; set; }
            public string edicion { get; set; }
            public int año { get; set; }
            public double precio { get; set; }

        }
 

